module RSpec
  module Expectations
    # @private
    module Version
      STRING = '3.1.2'
    end
  end
end
