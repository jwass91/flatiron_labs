module RSpec # :nodoc:
  module Version # :nodoc:
    STRING = '3.1.0'
  end
end
