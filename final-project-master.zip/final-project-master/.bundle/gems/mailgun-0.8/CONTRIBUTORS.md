* Alan deLevie / ([@adelevie](http://github.com/adelevie))
  * Sending email

* Andrés Bravo / ([@andresbravog](http://github.com/andresbravog))
  * Support for bounces API

* [@gabriel](http://github.com/gabriel)
  * Fix to accept domain in options

* Kaz Walker / [@KazW](http://github.com/KazW>)
  * Syntax highlighting for readme

* [@mirzac](http://github.com/mirzac>)
  * Fix to accept domain in options

* [@kdayton-](http://github.com/kdayton->)
  * Support for domains API

* Scott Carleton / [@scotterc](http://github.com/scotterc)
  * new functionality and improvements

* Yomi Colledge / [@baphled](http://github.com/baphled)
  * For refactoring API configuration and some documentation