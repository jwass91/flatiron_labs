module Mailgun
  class Error < StandardError
  end
end
