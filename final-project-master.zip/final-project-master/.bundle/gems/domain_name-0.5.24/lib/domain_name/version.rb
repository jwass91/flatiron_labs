class DomainName
  VERSION = "0.5.24"
end
