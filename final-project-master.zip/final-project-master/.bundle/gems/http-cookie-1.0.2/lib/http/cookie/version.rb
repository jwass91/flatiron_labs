module HTTP
  class Cookie
    VERSION = "1.0.2"
  end
end
