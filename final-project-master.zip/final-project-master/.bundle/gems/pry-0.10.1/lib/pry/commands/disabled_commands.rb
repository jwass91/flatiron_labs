Pry::Commands.disabled_command("edit-method", "Use `edit` instead.")
Pry::Commands.disabled_command("show-command", "Use show-source [command_name] instead.")
