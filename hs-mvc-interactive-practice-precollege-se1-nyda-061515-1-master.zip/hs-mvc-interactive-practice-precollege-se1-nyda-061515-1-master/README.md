---
tags: kids, mvc
languages: ruby
type: interactive practice
---

##Interactive Practice: Model-View-Controller

Fork and clone this repository and follow along in lecture!

(WIP)


