---
tags: methods, return values, kids, ruby
language: ruby
level: 1
type: lab
---

# A Subway Story

![subway balloons](http://1.media.collegehumor.cvcdn.com/28/26/beeb4cb32e3896b1659854ad8977c847-the-new-york-city-subway-what-you-can-expect.jpg)

Fork and clone this lab and follow the instructions in `subway_methods.rb` to write the appropriate methods. 

The first method is written out for you as an example. Don't forget to run your program after you are done.
