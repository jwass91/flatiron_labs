require_relative "../pig_latin"

RSpec.configure do |config|
  # config here
end
