require_relative '../config/environment'

require 'fileutils'
require 'open-uri'

RSpec.configure do |config|
  # config here
end
