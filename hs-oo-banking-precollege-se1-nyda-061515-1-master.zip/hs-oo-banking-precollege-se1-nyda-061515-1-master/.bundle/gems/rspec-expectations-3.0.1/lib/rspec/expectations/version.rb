module RSpec
  module Expectations
    # @private
    module Version
      STRING = '3.0.1'
    end
  end
end
