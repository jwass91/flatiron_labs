require 'rspec/mocks'
include RSpec::Mocks::ExampleMethods
RSpec::Mocks.setup
