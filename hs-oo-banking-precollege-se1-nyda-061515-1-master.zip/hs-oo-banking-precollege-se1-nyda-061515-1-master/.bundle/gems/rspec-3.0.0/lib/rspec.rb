require 'rspec/core'
require 'rspec/version'

