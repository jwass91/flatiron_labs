module MethodSource
  VERSION = "0.8.2"
end
