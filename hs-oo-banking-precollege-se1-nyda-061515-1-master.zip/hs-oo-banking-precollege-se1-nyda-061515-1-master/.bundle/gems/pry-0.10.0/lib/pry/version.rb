class Pry
  VERSION = "0.10.0"
end
