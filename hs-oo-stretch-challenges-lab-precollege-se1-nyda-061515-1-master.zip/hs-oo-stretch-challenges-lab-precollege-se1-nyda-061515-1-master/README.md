---
tags: oo, kids
language: ruby
level: 3
type: stretch, lab
---

# Get Stretching!

<img src="https://after-school-assets.s3.amazonaws.com/cat-stretch.jpg">

Get all the tests passing. Go into `spec/000_dogs_spec.rb` and follow the instructions to get started.
# strechlab
