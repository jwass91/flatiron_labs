# Create a class dice with a single method `roll` that returns a random number
# between 1 and 6

# Feel free to google "how to generate a random number in ruby"

class Dice

  def roll
    1 + rand(6) 
  end

end