# Tip Calculator Project

This is our Tip Calculator! This web-application asks the user how much their bill was, what percentage they would like to tip, how much the tax was, and how many people they would like to split the bill between. The application then calculates the total per person(including tax, tip and the original bill). We hope that you enjoy our program!
