
# Fibonacci Numbers
Solve for fibonacci numbers using loops conditionals and arrays.

# Skills: arrays, methods, conditional logic
# Instructions: 
Create a method that returns the nth number of the fibonacci sequence 
- The fibonacci sequence = 0,1,1,2,3,5,8,13 etc 
- For our purposes if n = 0 the element is 0 (the first number), if n = 1 the element is 1, n = 2 the element is 1.
