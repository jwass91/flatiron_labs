def fibo_finder(n)
  # code goes here
end