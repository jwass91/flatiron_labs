---
tags: methods, return values, kids, ruby
language: ruby
level: 1
type: lab
---

##Polly Wants a Cracker?

![parrot](http://1.bp.blogspot.com/-HDI-XiLird8/ToaJsehSY0I/AAAAAAAABso/XHXOU_qDK3k/s1600/Parrot+Funny+Pictures_1.jpg)

In this lab you'll be training some parrots with special talents. 

Fork and clone this lab and follow along and write your code in the `parrot.rb` file. Try running your program when you are done. (Hint - You'll be chaining methods, so pay attention to your return values!) 

## Resources
* [Learn to Program](http://books.flatironschool.com/books/43?page=72) - [9.1 Method Parameters](http://books.flatironschool.com/books/43?page=72), page 72
