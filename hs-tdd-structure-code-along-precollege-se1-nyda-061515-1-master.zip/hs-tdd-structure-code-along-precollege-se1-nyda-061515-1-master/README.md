##TDD/Rspec Code-Along!

This is a code-along file for our lecture on Test Driven Development. Clone this directory to your computer and wait for instructions :). For more information on how TDD works, check out the Study Guide for this lesson.
