class Gotham

  def initialize
    @villains = ["Penguin", "The Joker", "Cat Woman"]
    @heroes = ["Batman"]
  end

  def send_bat_signal(crime)
    # Return a string that asks for Batman's help with a specific crime!

  end

  def count_villains
    # Determine how many villains are in the @villains array
    # If there are less than three return the string "Batman's got this!", otherwise return a string asking Robin for help

  end

  def add_hero(hero)
    # Batman needs help!
    # Write out the code to add a hero to the heroes array

  end

  def defeat_villain
    # Batman is picking off Gotham's enemies one at a time
    # Write a method that removes the last enemy in the array and declares that villain's defeat 
    
  end

  def catalogue_weapons
    # The city is helping Batman take stock of his enemies
    # Write out code to create a hash with key value pairs for each villain and their weapon of choice
    # Do this by iterating over the @villains array and asking for input on what each villain's weapon should be
    # Your last line of code should return your completed hash 
  end
end

