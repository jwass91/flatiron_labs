---
  tags: classes, arrays, hashes, kids, ruby  
  languages: ruby
  level: 2
  type: code challenge
---

## Save Gotham!

![batman](http://media0.giphy.com/media/iGGHjzCxell2o/200.gif)

The fate of the Gotham lies in the balance! Fork and clone this lab and make the tests pass to help Batman save the city.
